import tkinter as tk
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier

# Load the dataset
data = pd.read_csv(r"C:\Users\Rakshitha\Downloads\Dataset-password.csv")
print("Data set Details")
print(data.head(10))
print("\n")
data = data.dropna()
data["strength"] = data["strength"].map({0: "Weak", 
                                         1: "Medium",
                                         2: "Strong"})
print("\'"+"After mapping the Dataset Details"+"\'")
print(data.head(5))
print("\n")
type = data["strength"].value_counts()
transactions = type.index
quantity = type.values

import plotly.express as px
figure = px.pie(data, 
             values=quantity, 
             names=transactions,hole = 0.5, 
             title="Distribution of Strength Of the Password")
figure.show()

# Preprocess the data
data = data.drop_duplicates(subset='password')
data = data.sample(frac=1).reset_index(drop=True)
X = data['password']
y = data['strength']

# Feature extraction using TfidfVectorizer
vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(1, 3))
X = vectorizer.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)
print("\'"+"Accurracy of Decision tree Score"+"\'")
print(clf.score(X_test, y_test))
print("\n")

import tkinter as tk

def check_password_strength():
    password = password_entry.get()
    if not password or len(password) < 5 or len(password) >13:
        strength_label.configure(text="Enter the password which contains characters between 5 and 13 ")
        return
    password_features = vectorizer.transform([password])
    password_strength = clf.predict(password_features)[0]
    strength_label.configure(text=f"Password Strength: {password_strength}")

root = tk.Tk()
root.title("\'"+"Password Strength Checker"+"\'")

password_label = tk.Label(root, text="Enter Password:", font=("Arial", 16))
password_label.grid(row=0, column=0, padx=10, pady=10)

password_entry = tk.Entry(root, show="*", font=("Arial", 16))
password_entry.grid(row=0, column=1, padx=10, pady=10)

check_button = tk.Button(root, text="Check Password Strength",font=("Arial", 16), command=check_password_strength)
check_button.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

strength_label = tk.Label(root, text="", font=("Arial", 16))
strength_label.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

root.mainloop()
